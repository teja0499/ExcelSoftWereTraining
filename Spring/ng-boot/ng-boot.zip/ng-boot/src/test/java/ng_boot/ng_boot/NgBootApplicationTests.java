package ng_boot.ng_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NgBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
