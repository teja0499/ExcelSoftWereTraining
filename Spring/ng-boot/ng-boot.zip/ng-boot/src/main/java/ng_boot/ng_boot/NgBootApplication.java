package ng_boot.ng_boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NgBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(NgBootApplication.class, args);
	}

}
